import { AgriSmartDashboard } from "@/components/AgriSmartDashboard";

const Index = () => <AgriSmartDashboard />;

export default Index;
