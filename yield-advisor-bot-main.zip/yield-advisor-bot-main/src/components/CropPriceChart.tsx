import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { BarChart3 } from "lucide-react";

const data = [
  { crop: "Wheat", price: 2450, change: 3.2 },
  { crop: "Corn", price: 1890, change: -1.1 },
  { crop: "Rice", price: 3200, change: 2.8 },
  { crop: "Soybean", price: 4100, change: 5.4 },
  { crop: "Cotton", price: 6800, change: -0.6 },
];

const COLORS = [
  "hsl(142, 60%, 45%)",
  "hsl(38, 90%, 55%)",
  "hsl(200, 80%, 55%)",
  "hsl(142, 60%, 55%)",
  "hsl(38, 70%, 50%)",
];

export function CropPriceChart({ visible }: { visible: boolean }) {
  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <BarChart3 className="h-4 w-4 text-accent" />
        <span className="text-sm font-semibold text-foreground">
          Crop Prices (₹/quintal)
        </span>
      </div>
      <div className="h-64 p-4">
        {!visible ? (
          <div className="flex h-full items-center justify-center text-muted-foreground text-sm italic">
            Chart will appear after market analysis...
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(150, 10%, 18%)" />
              <XAxis
                dataKey="crop"
                tick={{ fill: "hsl(140, 8%, 55%)", fontSize: 12 }}
                axisLine={{ stroke: "hsl(150, 10%, 18%)" }}
              />
              <YAxis
                tick={{ fill: "hsl(140, 8%, 55%)", fontSize: 12 }}
                axisLine={{ stroke: "hsl(150, 10%, 18%)" }}
              />
              <Tooltip
                contentStyle={{
                  background: "hsl(150, 15%, 10%)",
                  border: "1px solid hsl(150, 10%, 18%)",
                  borderRadius: "8px",
                  color: "hsl(140, 15%, 90%)",
                  fontSize: 13,
                }}
              />
              <Bar dataKey="price" radius={[6, 6, 0, 0]}>
                {data.map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
