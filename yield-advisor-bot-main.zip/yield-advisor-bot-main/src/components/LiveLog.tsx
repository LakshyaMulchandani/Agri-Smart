import { useEffect, useRef } from "react";
import { Terminal } from "lucide-react";

export function LiveLog({ logs }: { logs: string[] }) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <Terminal className="h-4 w-4 text-primary" />
        <span className="text-sm font-semibold text-foreground">Live Log</span>
        <span className="ml-auto text-xs text-muted-foreground font-mono">
          {logs.length} entries
        </span>
      </div>
      <div className="h-64 overflow-y-auto bg-background/50 p-4 font-mono text-sm">
        {logs.length === 0 ? (
          <p className="text-muted-foreground italic">
            Waiting for analysis to start...
          </p>
        ) : (
          logs.map((log, i) => (
            <div
              key={i}
              className="animate-in fade-in slide-in-from-left-2 py-0.5 text-foreground/90"
              style={{ animationDelay: `${i * 30}ms` }}
            >
              <span className="text-muted-foreground mr-2 select-none">
                [{String(i + 1).padStart(2, "0")}]
              </span>
              {log}
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
