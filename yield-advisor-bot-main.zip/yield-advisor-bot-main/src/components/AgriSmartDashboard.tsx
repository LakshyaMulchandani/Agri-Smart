import { useState, useCallback, useRef } from "react";
import { WorkflowSteps } from "./WorkflowSteps";
import { LiveLog } from "./LiveLog";
import { CropPriceChart } from "./CropPriceChart";
import { AlertPanel } from "./AlertPanel";
import { Sprout, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const LOG_MESSAGES = [
  { text: "🌤 Checking weather data...", delay: 600 },
  { text: "🌧 Rain probability is 72%", delay: 1200 },
  { text: "🌡 Temperature forecast: 28°C avg", delay: 1800 },
  { text: "📊 Checking market prices...", delay: 2800 },
  { text: "🌾 Wheat: ₹2,450/quintal (+3.2%)", delay: 3400 },
  { text: "🌽 Corn: ₹1,890/quintal (-1.1%)", delay: 3900 },
  { text: "🚛 Checking logistics routes...", delay: 5000 },
  { text: "📦 Warehouse capacity: 78% full", delay: 5600 },
  { text: "🛣 Optimal route: NH-44 → Depot B", delay: 6200 },
  { text: "🧠 Running strategic analysis...", delay: 7400 },
  { text: "✅ Analysis complete.", delay: 8400 },
];

const STEP_TIMINGS = [0, 2400, 4600, 7000];

const ALERT_ADVICE =
  "⚠️ High rain probability (72%) detected. Delay wheat harvest by 3 days. Shift logistics to Route B via NH-44. Corn prices declining — consider holding stock. Prioritize warehouse consolidation at Depot B.";

export function AgriSmartDashboard() {
  const [activeStep, setActiveStep] = useState(-1);
  const [logs, setLogs] = useState<string[]>([]);
  const [showChart, setShowChart] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [running, setRunning] = useState(false);
  const timers = useRef<number[]>([]);

  const runAnalysis = useCallback(() => {
    // Reset
    timers.current.forEach(clearTimeout);
    setActiveStep(-1);
    setLogs([]);
    setShowChart(false);
    setShowAlert(false);
    setRunning(true);

    // Steps
    STEP_TIMINGS.forEach((delay, i) => {
      timers.current.push(window.setTimeout(() => setActiveStep(i), delay));
    });

    // Logs
    LOG_MESSAGES.forEach(({ text, delay }) => {
      timers.current.push(
        window.setTimeout(() => setLogs((prev) => [...prev, text]), delay)
      );
    });

    // Chart after market step
    timers.current.push(window.setTimeout(() => setShowChart(true), 4200));

    // Alert at end
    timers.current.push(
      window.setTimeout(() => {
        setShowAlert(true);
        setRunning(false);
      }, 9000)
    );
  }, []);

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <header className="mb-8 flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20">
            <Sprout className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-foreground">
              Agri-Smart
            </h1>
            <p className="text-sm text-muted-foreground">
              Intelligent Agricultural Decision Engine
            </p>
          </div>
        </div>
        <Button
          onClick={runAnalysis}
          disabled={running}
          size="lg"
          className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90 font-semibold text-base px-6 disabled:opacity-50"
        >
          <Zap className="h-5 w-5" />
          {running ? "Analyzing..." : "Run Smart Analysis"}
        </Button>
      </header>

      <WorkflowSteps activeStep={activeStep} />

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <LiveLog logs={logs} />
        <CropPriceChart visible={showChart} />
      </div>

      <AlertPanel visible={showAlert} message={ALERT_ADVICE} />
    </div>
  );
}
