import { CloudSun, TrendingUp, Truck, Brain, Check } from "lucide-react";

const steps = [
  { label: "Environmental", icon: CloudSun },
  { label: "Market", icon: TrendingUp },
  { label: "Logistics", icon: Truck },
  { label: "Strategist", icon: Brain },
];

export function WorkflowSteps({ activeStep }: { activeStep: number }) {
  return (
    <div className="flex items-center justify-between gap-2 rounded-xl border border-border bg-card p-4 overflow-x-auto">
      {steps.map((step, i) => {
        const done = activeStep > i;
        const active = activeStep === i;
        const Icon = step.icon;

        return (
          <div key={step.label} className="flex flex-1 items-center gap-2 min-w-0">
            <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
              <div
                className={`flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all duration-500 ${
                  done
                    ? "border-primary bg-primary text-primary-foreground"
                    : active
                    ? "border-primary bg-primary/20 text-primary animate-pulse"
                    : "border-border bg-secondary text-muted-foreground"
                }`}
              >
                {done ? <Check className="h-5 w-5" /> : <Icon className="h-5 w-5" />}
              </div>
              <span
                className={`text-xs font-medium transition-colors ${
                  done || active ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {step.label}
              </span>
            </div>
            {i < steps.length - 1 && (
              <div
                className={`h-0.5 flex-1 rounded transition-colors duration-500 ${
                  done ? "bg-primary" : "bg-border"
                }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
