import { AlertTriangle } from "lucide-react";

export function AlertPanel({
  visible,
  message,
}: {
  visible: boolean;
  message: string;
}) {
  if (!visible) return null;

  return (
    <div className="mt-6 animate-in fade-in slide-in-from-bottom-4 duration-500 rounded-xl border-2 border-destructive/60 bg-destructive/10 p-5">
      <div className="flex items-start gap-3">
        <AlertTriangle className="h-6 w-6 flex-shrink-0 text-destructive mt-0.5" />
        <div>
          <h3 className="text-sm font-bold text-destructive mb-1">
            Strategic Advisory Alert
          </h3>
          <p className="text-sm text-foreground/90 leading-relaxed">{message}</p>
        </div>
      </div>
    </div>
  );
}
